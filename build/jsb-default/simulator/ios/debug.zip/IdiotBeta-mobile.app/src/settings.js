_CCSettings = {
    "platform": "ios",
    "groupList": [
        "default",
        "boundary",
        "status"
    ],
    "collisionMatrix": [
        [
            true,
            true,
            false
        ],
        [
            true,
            true,
            false
        ],
        [
            false,
            false,
            true
        ]
    ],
    "rawAssets": {
        "assets": {
            "d7bH6eVn5KrINR7oK0mMSI": [
                "audio/bgm.mp3",
                "cc.AudioClip"
            ],
            "9cp8FTE+dLkqpPjpIRY2dV": [
                "audio/chaos.mp3",
                "cc.AudioClip"
            ],
            "b27UlcPeVDo46PCYr4rxUy": [
                "audio/deadCall.mp3",
                "cc.AudioClip"
            ],
            "e4K1DWyJhMdpHZwv4QRuKC": [
                "audio/gameover.wav",
                "cc.AudioClip"
            ],
            "fb2AzQ1+VLLKwTr02HUrip": [
                "audio/jump.mp3",
                "cc.AudioClip"
            ],
            "e4lj2LSlJCbq7or5fGapWV": [
                "audio/land.mp3",
                "cc.AudioClip"
            ],
            "62E3C3l+9E/bueiUGfhLLz": [
                "audio/mainMenuBGM.mp3",
                "cc.AudioClip"
            ],
            "d8l9008kxI5Z3S4//m3aUY": [
                "audio/rage.mp3",
                "cc.AudioClip"
            ],
            "0fvZAgvP5BpYUb9BMYp340": [
                "resources/chaos",
                "cc.SpriteFrame",
                1
            ],
            "55FQZh4k1H+aGo+9xzllh4": [
                "resources/chaos.png",
                "cc.Texture2D"
            ],
            "b1Y0sMHmRKFZtzZ6HvKggI": [
                "resources/rage",
                "cc.SpriteFrame",
                1
            ],
            "25QsLxEKVGPqJMa4wIVv+F": [
                "resources/rage.png",
                "cc.Texture2D"
            ],
            "00fsGK95tPTbjIGCrfW2WV": [
                "textures/floor-long.png",
                "cc.Texture2D"
            ],
            "fdJJTTRJdOb4E2ogCt9RKC": [
                "textures/ground.png",
                "cc.Texture2D"
            ],
            "f662oBUylFM7N50j3uMXfg": [
                "textures/player.png",
                "cc.Texture2D"
            ],
            "c8NmdPvTdLf50qB90v7S7+": [
                "textures/player3.png",
                "cc.Texture2D"
            ],
            "19zJEYJmZK8qJn98i32Rvu": [
                "textures/player4.png",
                "cc.Texture2D"
            ],
            "3cDN0j4vxNM7Tawv7L9YE9": [
                "textures/player5.png",
                "cc.Texture2D"
            ]
        },
        "internal": {
            "71VhFCTINJM6/Ky3oX9nBT": [
                "image/default_btn_disabled.png",
                "cc.Texture2D"
            ],
            "e8Ueib+qJEhL6mXAHdnwbi": [
                "image/default_btn_normal.png",
                "cc.Texture2D"
            ],
            "b4P/PCArtIdIH38t6mlw8Y": [
                "image/default_btn_pressed.png",
                "cc.Texture2D"
            ]
        }
    },
    "launchScene": "db://assets/mainMenu.fire",
    "scenes": [
        {
            "url": "db://assets/mainMenu.fire",
            "uuid": "27L1JgiqVOwKzPY20FgZIk"
        },
        {
            "url": "db://assets/gameOver.fire",
            "uuid": "57TR+wthFPWqgu4MYmMzn/"
        },
        {
            "url": "db://assets/main.fire",
            "uuid": "09JrUEQ1dIhptvZ5Y56/8J"
        },
        {
            "url": "db://assets/credits.fire",
            "uuid": "c7kVzjLSJGKoPjwvmbPwIi"
        },
        {
            "url": "db://assets/score.fire",
            "uuid": "9dxz65o+JI66BMFPy3+guD"
        },
        {
            "url": "db://assets/tutorial.fire",
            "uuid": "35+NDp+jVDJJYAd909gv+N"
        }
    ],
    "packedAssets": {
        "0378d791c": [
            "0ckzFMouBJW5WJcUGLgz+6",
            "341kAE2u1IZJoAyqGeblY0",
            "61HesHiGVGR5RS1wW2Nx0V",
            "a2Tug8GrRFdrIZfuPy4Ate",
            "f7TT24zyZMg5+5XlykbaHP"
        ],
        "03e79f7f2": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "57TR+wthFPWqgu4MYmMzn/",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "05048fb2e": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "9dxz65o+JI66BMFPy3+guD",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "064806ace": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "35+NDp+jVDJJYAd909gv+N",
            "9bTCaxzXJKCqV1PsErKPFl",
            "a2Tug8GrRFdrIZfuPy4Ate",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "082a4ef6a": [
            "09JrUEQ1dIhptvZ5Y56/8J",
            "88IVworpFHkqfjRMnUxkvX",
            "9bTCaxzXJKCqV1PsErKPFl",
            "a2Tug8GrRFdrIZfuPy4Ate"
        ],
        "082a6cca3": [
            "8f1wcNf7RDHoAQ5OeZ06d4",
            "a2Tug8GrRFdrIZfuPy4Ate"
        ],
        "09f5b90e2": [
            "9bTCaxzXJKCqV1PsErKPFl",
            "aci5dXwSJLkpDG8rIlfWU1"
        ],
        "0acb6e1c8": [
            "27L1JgiqVOwKzPY20FgZIk",
            "29FYIk+N1GYaeWH/q1NxQO",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "0f80fa1f2": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "c7kVzjLSJGKoPjwvmbPwIi",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ]
    },
    "orientation": "",
    "debug": true
};
