require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var a = "function" == typeof require && require;
        if (!u && a) return a(o, !0);
        if (i) return i(o, !0);
        var f = new Error("Cannot find module '" + o + "'");
        throw f.code = "MODULE_NOT_FOUND", f;
      }
      var l = n[o] = {
        exports: {}
      };
      t[o][0].call(l.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, l, l.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof require && require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  about: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "29063LKi4RAdIJFroXHVgj0", "about");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      toAbout: function toAbout() {
        cc.director.loadScene("credits");
      }
    });
    cc._RF.pop();
  }, {} ],
  creditsScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1414em23WRLWYbnMEmAiqMd", "creditsScene");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        highestScoreText: {
          default: null,
          type: cc.Label
        }
      },
      onLoad: function onLoad() {
        var userData = cc.sys.localStorage.getItem("userData");
        if (userData) {
          var score = JSON.parse(userData).highestScore;
          this.highestScoreText.string = "High Score:" + score;
        } else this.highestScoreText.string = "High Score:0";
      }
    });
    cc._RF.pop();
  }, {} ],
  credits: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "aed48KjPzRMSJwg0buSyeEL", "credits");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      toCredits: function toCredits() {
        cc.director.loadScene("score");
      }
    });
    cc._RF.pop();
  }, {} ],
  floor: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d00f9JwtYlFD4fK42Es2sYv", "floor");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        xFloorPosition: 0,
        yFloorPosition: 0,
        floorAngle: 0,
        maxFloorAngle: 30,
        baseRotateAngle: 15,
        rotateAngle: 0,
        baseRotateDuration: .1,
        rotateDuration: .03,
        isPlayerOn: false,
        floorSpeed: 1,
        floorBaseSpeed: 1,
        speedAddRate: 1
      },
      onLoad: function onLoad() {},
      setFloorRiseSpeed: function setFloorRiseSpeed(speed) {
        this.floorSpeed = speed;
      },
      floorRise: function floorRise() {
        this.node.y += this.floorSpeed;
      },
      update: function update(dt) {
        this.floorRise();
        var score = this.game ? this.game.score : 1;
        this.speedIncrease(score);
      },
      speedIncrease: function speedIncrease(score) {
        this.floorSpeed = score < 10 ? this.floorBaseSpeed : score >= 10 && score < 30 ? this.floorBaseSpeed + this.speedAddRate : score >= 30 && score < 70 ? this.floorBaseSpeed + 3 * this.speedAddRate : score >= 70 && score < 100 ? this.floorBaseSpeed + 4 * this.speedAddRate : this.floorBaseSpeed + 5 * this.speedAddRate;
      }
    });
    cc._RF.pop();
  }, {} ],
  gameOver: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fbed2Mq5/9ELpFjybh9sGrD", "gameOver");
    "use strict";
    var Global = require("global");
    cc.Class({
      extends: cc.Component,
      properties: {
        finalScore: {
          type: cc.Label,
          default: null
        },
        failedAudioSource: {
          url: cc.AudioClip,
          default: null
        }
      },
      onLoad: function onLoad() {
        var score = Global.score;
        this.finalScore.string = "FINAL SCORE:" + score;
        this.scheduleOnce(this.playDeadAudio, 1);
        var userData = JSON.parse(cc.sys.localStorage.getItem("userData"));
        if (userData.highestScore < score) {
          userData.highestScore = score;
          cc.sys.localStorage.setItem("userData", JSON.stringify(userData));
        }
      },
      playDeadAudio: function playDeadAudio() {
        cc.audioEngine.play(this.failedAudioSource, false, 1);
      }
    });
    cc._RF.pop();
  }, {
    global: "global"
  } ],
  game: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "efa0fyvDW9JFq2DvG55ZqpQ", "game");
    "use strict";
    var floorPositionArray = [];
    cc.Class({
      extends: cc.Component,
      properties: {
        areaWidth: 960,
        floorGap: 200,
        bottomFloorY: 0,
        bottomFloorX: 0,
        bottomFloor: {
          default: null,
          type: cc.Node
        },
        floorCount: 1,
        score: 0,
        otherFloor: {
          default: null,
          type: cc.Prefab
        },
        initFloor: {
          default: null,
          type: cc.Node
        },
        player: {
          default: null,
          type: cc.Node
        },
        counters: {
          default: null,
          type: cc.Label
        },
        backgroundAudioSource: {
          url: cc.AudioClip,
          default: null
        }
      },
      onLoad: function onLoad() {
        var BGM = cc.audioEngine.play(this.backgroundAudioSource, true, 1);
        cc.director.preloadScene("gameOver", function() {
          cc.log("gameOver scene preloaded");
        });
        cc.director.getPhysicsManager().enabled = true;
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        this.bottomFloorX = this.initFloor.x;
        this.bottomFloorY = this.initFloor.y;
        this.player.getComponent("player").game = this;
        this.player.getComponent("player").BGM = BGM;
        this.createNewFloor();
      },
      createNewFloor: function createNewFloor() {
        while (this.bottomFloorY > this.node.y - this.node.height) {
          var newFloor = cc.instantiate(this.otherFloor);
          this.node.addChild(newFloor);
          newFloor.getComponent("floor").game = this;
          this.setWidth(newFloor);
          newFloor.setPosition(this.setPosition(newFloor));
          this.bottomFloor = newFloor;
          newFloor.tag = this.floorCount;
          this.floorCount++;
        }
      },
      setPosition: function setPosition(newFloor) {
        var floorWidth = newFloor.width, minX = -this.areaWidth / 2 + floorWidth, maxX = this.areaWidth / 2 - floorWidth, floorX = 0, floorY = this.bottomFloorY - (Math.random() + 1.5) * this.floorGap, isPositionCError = true, index = 0, floorArrayLength = floorPositionArray.length;
        if (floorArrayLength > 1) {
          var preSecondIndex = floorPositionArray[floorArrayLength - 2], preOneIndex = floorPositionArray[floorArrayLength - 1], preIndexes = preOneIndex + preSecondIndex;
          switch (preIndexes) {
           case -3:
            index = preOneIndex < preSecondIndex ? cc.randomMinus1To1() >= 0 ? 0 : 1 : cc.randomMinus1To1() >= 0 ? 1 : 2;
            break;

           case -2:
            index = cc.randomMinus1To1() >= 0 ? 1 : 2;
            break;

           case -1:
            index = 0 === preOneIndex || 0 === preSecondIndex ? cc.randomMinus1To1() >= 0 ? 1 : 2 : this.getReversePosition(preOneIndex);
            break;

           case 0:
            index = this.getReversePosition(preOneIndex);
            break;

           case 1:
            index = 0 === preOneIndex || 0 === preSecondIndex ? cc.randomMinus1To1() >= 0 ? -1 : -2 : this.getReversePosition(preOneIndex);
            break;

           case 2:
            index = cc.randomMinus1To1() >= 0 ? -1 : -2;
            break;

           case 3:
            index = preOneIndex > preSecondIndex ? cc.randomMinus1To1() >= 0 ? 0 : -1 : cc.randomMinus1To1() >= 0 ? -1 : -2;
          }
        } else index = 0 === floorArrayLength ? 2 : cc.randomMinus1To1() >= 0 ? -1 : -2;
        switch (index) {
         case -1:
          floorX = minX;
          break;

         case -2:
          floorX = minX / 2;
          break;

         case 0:
          floorX = 0;
          break;

         case 1:
          floorX = maxX / 2;
          break;

         case 2:
          floorX = maxX;
          break;

         default:
          floorX = 0;
        }
        floorPositionArray.push(index);
        this.bottomFloorX = floorX;
        this.bottomFloorY = floorY;
        return cc.p(floorX, floorY);
      },
      getReversePosition: function getReversePosition(preOneIndex) {
        var index = 0;
        index = preOneIndex >= 0 ? cc.randomMinus1To1() >= 0 ? -1 : -2 : cc.randomMinus1To1() >= 0 ? 1 : 2;
        return index;
      },
      setWidth: function setWidth(newFloor) {
        var floorWidth = this.initFloor.width, box = newFloor.getComponent(cc.PhysicsBoxCollider);
        newFloor.width = floorWidth;
        box.size = cc.size(floorWidth, 1);
        box.apply();
      },
      setPositionSimple: function setPositionSimple(newFloor) {
        var floorWidth = newFloor.width, floorX = 0, floorY = this.bottomFloorY - (Math.random() + 1.5) * this.floorGap;
        floorX = this.bottomFloorX >= 0 ? -floorWidth / 2 : floorWidth / 2;
        this.bottomFloorX = floorX;
        this.bottomFloorY = floorY;
        return cc.p(floorX, floorY);
      },
      setWidthSimple: function setWidthSimple(newFloor) {
        var floorWidth = this.node.width / 2, box = newFloor.getComponent(cc.PhysicsBoxCollider);
        newFloor.width = floorWidth;
        box.size = cc.size(floorWidth, 1);
        box.apply();
      },
      update: function update(dt) {
        this.bottomFloorY = this.bottomFloor.y;
        this.createNewFloor();
      },
      setScore: function setScore(_score) {
        this.score = _score;
        this.counters.string = "Score：" + this.score.toString();
      }
    });
    module.exports = {
      floorArray: floorPositionArray
    };
    cc._RF.pop();
  }, {} ],
  global: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e311b2NEwJJOadAvoSYinYk", "global");
    "use strict";
    module.exports = {
      score: null,
      notFirst: false
    };
    cc._RF.pop();
  }, {} ],
  mainMenuBtn: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a7b74nWAbxH0reas2rk67Z+", "mainMenuBtn");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      reutnMainMenu: function reutnMainMenu() {
        cc.audioEngine.stopAll();
        cc.director.loadScene("mainMenu");
      },
      shareScore: function shareScore() {
        var agent = anysdk.agentManager;
        var share_plugin = agent.getSharePlugin();
        share_plugin.setListener(this.onShareResult, this);
        var info = {
          title: "测试标题",
          titleUrl: "http://sharesdk.cn",
          site: "ShareSDK",
          siteUrl: "http://sharesdk.cn",
          imagePath: "/sdcard/test.png",
          url: "http://sharesdk.cn",
          imageUrl: "http://www.baidu.com/img/bdlogo.png?tn=63090008_1_hao_pg",
          text: "测试，只是测试",
          comment: "测试中"
        };
        share_plugin.share(info);
      },
      onShareResult: function onShareResult(code, msg) {
        cc.log("share result, resultcode:" + code + ", msg: " + msg);
        switch (code) {
         case anysdk.ShareResultCode.kShareSuccess:
          alert("分享成功");
          break;

         case anysdk.ShareResultCode.kShareFail:
          alert("分享失败");
          break;

         case anysdk.ShareResultCode.kShareCancel:
          alert("分享取消");
          break;

         case anysdk.ShareResultCode.kShareNetworkError:
          alert("网络错误");
        }
      }
    });
    cc._RF.pop();
  }, {} ],
  mainMenu: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0c4a3/42thHU7eHay7Y16Hq", "mainMenu");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        BGMAudioSource: {
          url: cc.AudioClip,
          default: null
        }
      },
      onLoad: function onLoad() {
        this.preloadIndexScene();
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.quitGame, this);
        cc.sys.os == cc.sys.OS_ANDROID && cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.quitGame, this);
        cc.audioEngine.play(this.BGMAudioSource, true, 1);
      },
      quitGame: function quitGame() {
        cc.game.end();
      },
      preloadIndexScene: function preloadIndexScene() {
        cc.director.preloadScene("main", function() {
          cc.log("Main scene preloaded");
        });
        cc.director.preloadScene("tutorial", function() {
          cc.log("Tutorial scene preloaded");
        });
        cc.director.preloadScene("credits", function() {
          cc.log("Credits scene preloaded");
        });
        cc.director.preloadScene("about", function() {
          cc.log("About scene preloaded");
        });
      }
    });
    cc._RF.pop();
  }, {} ],
  player: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "93f33vjOIdMU6wSJmoj2IOa", "player");
    "use strict";
    var Global = require("global");
    var Game = require("game");
    var floorRestAction = null;
    cc.Class({
      extends: cc.Component,
      properties: {
        xPosition: 0,
        yPosition: 0,
        speed: 2,
        isOnFloor: true,
        jumpLevel: 5,
        baseSpeedLevel: 7,
        speedLevel: 3,
        fromFloorHeight: 20,
        stopRange: 5,
        moveYDuration: .2,
        fallDuration: 1,
        isStatusOn: true,
        status: 0,
        minStatusTime: 5,
        maxStatusTime: 10,
        jumpLandX: 0,
        currentFloor: {
          default: null,
          type: cc.Node
        },
        jumpAudioSource: {
          url: cc.AudioClip,
          default: null
        },
        landAudioSource: {
          url: cc.AudioClip,
          default: null
        },
        chaosAudioSource: {
          url: cc.AudioClip,
          default: null
        },
        rageAudioSource: {
          url: cc.AudioClip,
          default: null
        },
        deadAudioSource: {
          url: cc.AudioClip,
          default: null
        }
      },
      onLoad: function onLoad() {
        this.xPosition = this.currentFloor.x;
        this.yPosition = this.currentFloor.y + this.fromFloorHeight;
        this.currentFloor.getComponent("floor").isPlayerOn = true;
        cc.inputManager.setAccelerometerEnabled(true);
        cc.systemEvent.on(cc.SystemEvent.EventType.DEVICEMOTION, this.onDeviceMotionEvent, this);
        this.startStatusCheck(3 * cc.random0To1() + 5);
      },
      onDeviceMotionEvent: function onDeviceMotionEvent(event) {
        if (this.isOnFloor) {
          var deviceMotion = event.acc.x, distance = deviceMotion * this.speed * this.speedLevel, playerToFloorCenterDis = Math.sqrt((this.node.x - this.currentFloor.x) * (this.node.x - this.currentFloor.x) + (this.node.y - this.currentFloor.y) * (this.node.y - this.currentFloor.y)), _currentFloor = this.currentFloor.getComponent("floor");
          if (playerToFloorCenterDis < (this.currentFloor.width + this.node.width) / 2) this.groupMove(distance); else {
            this.playerFall(distance);
            this.floorRest();
          }
        }
      },
      onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        var otherColliderNode = otherCollider.node;
        if ("boundary" === otherColliderNode.group) {
          this.playerFailed();
          return;
        }
        if (otherColliderNode != this.currentFloor) {
          this.currentFloor = otherColliderNode;
          this.xPosition = this.node.x;
          this.setPlayerOnFloorState(true);
          var score = otherColliderNode.tag;
          this.game && this.game.setScore(score);
          this.playAudio(this, this.landAudioSource, false);
        } else {
          (floorRestAction && floorRestAction._instanceId || Global.notFirst) && this.currentFloor.stopAction(floorRestAction);
          this.setPlayerOnFloorState(true);
        }
      },
      onEndContact: function onEndContact(contact, selfCollider, otherCollider) {},
      onPreSolve: function onPreSolve(contact, selfCollider, otherCollider) {},
      onPostSolve: function onPostSolve(contact, selfCollider, otherCollider) {},
      setPlayerOnFloorState: function setPlayerOnFloorState(_switch) {
        this.isOnFloor = _switch;
        this.currentFloor.getComponent("floor").isPlayerOn = _switch;
      },
      groupMove: function groupMove(distance) {
        var playerYMoveDirecition = this.floorMove(), _currentFloor = this.currentFloor.getComponent("floor");
        this.playerMove(distance, playerYMoveDirecition, _currentFloor);
      },
      playerMove: function playerMove(distance, playerYMoveDirecition, _currentFloor) {
        var _floorAngle = this.currentFloor.rotation, yMoveDistance = distance * Math.sin(.0174533 * Math.abs(_floorAngle));
        this.xPosition += distance * Math.cos(.0174533 * Math.abs(_floorAngle));
        this.speedLevel = _floorAngle * distance ? this.baseSpeedLevel + Math.abs(_floorAngle) : this.baseSpeedLevel - Math.abs(_floorAngle);
      },
      floorMove: function floorMove() {
        var playerXPosition = this.xPosition, distanceFromCenter = playerXPosition - this.currentFloor.x, playerYMoveDirecition = true, floorWidth = this.currentFloor.width, _currentFloor = this.currentFloor.getComponent("floor");
        distanceFromCenter <= -this.stopRange ? _currentFloor.rotateAngle = -_currentFloor.baseRotateAngle : _currentFloor.rotateAngle = Math.abs(_currentFloor.baseRotateAngle);
        playerYMoveDirecition = _currentFloor.floorAngle > 0;
        return playerYMoveDirecition;
      },
      update: function update(dt) {
        if (this.isOnFloor) {
          var _currentFloor = this.currentFloor.getComponent("floor"), floorRotate = cc.rotateBy(_currentFloor.rotateDuration, _currentFloor.rotateAngle), callback = cc.callFunc(this.getFloorAngle, this, _currentFloor), _maxFloorAngle = _currentFloor.maxFloorAngle - _currentFloor.baseRotateAngle;
          this.node.x = this.xPosition;
          (_currentFloor.floorAngle < _maxFloorAngle && _currentFloor.floorAngle > -_maxFloorAngle || _currentFloor.floorAngle * _currentFloor.rotateAngle <= 0) && this.currentFloor.runAction(cc.sequence(floorRotate, callback));
        } else if (this.game) {
          var sceneWidth = this.game.node.width, sceneHeight = this.game.node.height, leftBound = -sceneWidth / 2, rightBound = sceneWidth / 2, bottomBound = -sceneHeight / 2, playerX = this.node.x, playerY = this.node.y;
          (playerX <= leftBound || playerX >= rightBound || playerY < bottomBound) && this.playerFailed();
        }
      },
      getFloorAngle: function getFloorAngle(currentFloor) {
        var _currentFloor = currentFloor.getComponent("floor");
        _currentFloor.floorAngle = this.currentFloor.rotation;
      },
      playerFall: function playerFall(distance) {
        this.setPlayerOnFloorState(false);
        var playerSpeed = Math.abs(this.speed), _jumpLevel = this.jumpLevel + Math.abs(distance / 3), landX = playerSpeed * distance * _jumpLevel, jumpHeight = this.setJumpHeight(Math.abs(distance)), callback = cc.callFunc(this.playAudio, this, this.jumpAudioSource, false), fallXMove = cc.jumpBy(this.fallDuration, cc.p(landX, 0), jumpHeight, 1).easing(cc.easeOut(3));
        this.jumpLandX = this.xPosition + landX;
        this.node.runAction(cc.sequence(callback, fallXMove));
      },
      floorRest: function floorRest() {
        floorRestAction = cc.rotateTo(.5, 0);
        this.currentFloor.runAction(floorRestAction);
      },
      playerFailed: function playerFailed() {
        Game.floorArray.splice(0, Game.floorArray.length);
        this.playAudio(this, this.deadAudioSource, false);
        Global.score = this.game.score;
        cc.director.loadScene("gameOver");
        cc.audioEngine.stop(this.BGM);
      },
      startStatusCheck: function startStatusCheck(_duration) {
        this.scheduleOnce(this.playerStatusChange, _duration);
      },
      playerStatusChange: function playerStatusChange() {
        var randomNum = Math.random();
        if (this.isStatusOn && 0 === this.status) {
          this.status = randomNum <= .3 ? 1 : 2;
          this.statusControl(this.status);
        }
      },
      statusControl: function statusControl(status) {
        var statusNode = this.node.getChildByName("Status"), statusNodeSprite = statusNode.getComponent(cc.Sprite), statusTime = (this.maxStatusTime - this.minStatusTime) * Math.random() + this.minStatusTime;
        switch (status) {
         case 0:
          this.statusNormal(statusNode);
          break;

         case 1:
          this.statusChaos(statusNode, statusNodeSprite);
          break;

         case 2:
          this.statusRage(statusNode, statusNodeSprite);
        }
        this.scheduleOnce(function() {
          this.statusNormal(statusNode);
        }, parseInt(statusTime));
      },
      statusNormal: function statusNormal(statusNode) {
        this.status = 0;
        statusNode.active = false;
        this.baseSpeedLevel = 1;
        this.speed = Math.abs(this.speed);
        this.startStatusCheck(5 * cc.random0To1() + 10);
      },
      statusChaos: function statusChaos(statusNode, statusNodeSprite) {
        var that = this;
        that.status = 1;
        that.loadImage("chaos", function(_spriteFrame) {
          statusNode.setContentSize(cc.size(47.7, 84));
          statusNodeSprite.spriteFrame = _spriteFrame;
          statusNode.active = true;
          that.playAudio(that, that.chaosAudioSource, false);
        });
        that.speed = -that.speed;
      },
      statusRage: function statusRage(statusNode, statusNodeSprite) {
        var that = this;
        that.status = 2;
        that.loadImage("rage", function(_spriteFrame) {
          statusNode.setContentSize(cc.size(62.9, 61.2));
          statusNodeSprite.spriteFrame = _spriteFrame;
          statusNode.active = true;
          that.playAudio(that, that.rageAudioSource, false);
        });
        that.baseSpeedLevel = 5 * Math.abs(that.baseSpeedLevel);
      },
      setJumpHeight: function setJumpHeight(distance) {
        var jumpHeight = 0;
        jumpHeight = distance <= 10 ? 20 : distance <= 20 ? 80 : 100;
        return jumpHeight;
      },
      playAudio: function playAudio(target, audioSource, isLoop) {
        cc.audioEngine.play(audioSource, isLoop, 1);
      },
      loadImage: function loadImage(filePath, callback) {
        var url = filePath;
        cc.loader.loadRes(url, cc.SpriteFrame, function(err, _spriteFrame) {
          callback(_spriteFrame);
        });
      }
    });
    cc._RF.pop();
  }, {
    game: "game",
    global: "global"
  } ],
  startGame: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fd2a6+LDgpNMZ5TyI1oD6oG", "startGame");
    "use strict";
    var Global = require("global");
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      startGame: function startGame() {
        var userData = cc.sys.localStorage.getItem("userData");
        cc.audioEngine.stopAll();
        if (userData) {
          cc.director.loadScene("main");
          Global.notFirst = true;
        } else cc.director.loadScene("tutorial");
      }
    });
    cc._RF.pop();
  }, {
    global: "global"
  } ],
  tutorial: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5e3f9LcbHNJNopHyWGAVcxd", "tutorial");
    "use strict";
    var tutorialIndex = 1, isPlayerStop = true, tutorialTwoGoals = {
      left: 0,
      right: 0
    };
    cc.Class({
      extends: cc.Component,
      properties: {
        player: {
          default: null,
          type: cc.Node
        },
        floor: {
          default: null,
          type: cc.Node
        },
        floorJump: {
          default: null,
          type: cc.Node
        },
        tutorialText: {
          default: null,
          type: cc.Label
        }
      },
      onLoad: function onLoad() {
        cc.director.preloadScene("main", function() {
          cc.log("Main scene preloaded");
        });
        cc.director.getPhysicsManager().enabled = true;
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        cc.inputManager.setAccelerometerEnabled(true);
        this.player.getComponent("player").isStatusOn = false;
        this.node.on(cc.Node.EventType.TOUCH_START, this.tutorialProgress, this);
        this.tutorialProgress();
      },
      onDeviceMotionEvent: function onDeviceMotionEvent(event) {
        isPlayerStop && this.scheduleOnce(this.setPlayerMotion, 1);
        if (2 === tutorialIndex) if (tutorialTwoGoals.left >= 10 && tutorialTwoGoals.right >= 20) {
          this.initMotionNode();
          this.tutorialText.string = "complete! Congratulations (click on the screen to continue)";
          tutorialIndex = 3;
        } else {
          var floorWidth = this.floor.width, playerWidth = this.player.width, floorX = this.floor.x, floorY = this.floor.y, playerX = this.player.x, playerY = this.player.y, distanceFromCenter = Math.sqrt((playerX - floorX) * (playerX - floorX) + (playerY - floorY) * (playerY - floorY));
          playerX >= floorX ? tutorialTwoGoals.right++ : tutorialTwoGoals.left++;
        }
      },
      setPlayerMotion: function setPlayerMotion() {
        this.player.getComponent("player").speed = 2;
        this.floor.getComponent("floor").baseRotateAngle = 15;
        isPlayerStop = false;
      },
      tutorialProgress: function tutorialProgress() {
        switch (tutorialIndex) {
         case 1:
          this.tutorialOne();
          break;

         case 2:
          this.tutorialTwo();
          break;

         case 3:
          this.tutorialThree();
          break;

         case 4:
          this.tutorialFour();
          break;

         case 5:
          this.tutorialFive();
          break;

         case 6:
          this.tutorialSix();
          break;

         case 7:
          this.tutorialSeven();
          break;

         case 8:
          this.skipTutorial();
          break;

         default:
          this.tutorialOne();
        }
      },
      tutorialOne: function tutorialOne() {
        var tutorialString = "欢迎来到Idiot游戏！下面我们将引导你进行游戏的基础操作教程（点击屏幕继续）";
        var tutorialString = "Welcome to Idiot! Here we will guide you through the tutorial of game (click on the screen to continue)";
        this.tutorialText.string = tutorialString;
        tutorialIndex = 2;
        this.initMotionNode();
      },
      tutorialTwo: function tutorialTwo() {
        cc.systemEvent.on(cc.SystemEvent.EventType.DEVICEMOTION, this.onDeviceMotionEvent, this);
        var tutorialString = "现在试着轻轻摇动你的手机来控制人物的左右移动";
        var tutorialString = "Now try to shake your phone gently to control the movement of people around";
        this.tutorialText.string = tutorialString;
        var textNode = this.tutorialText.node;
        textNode.setPosition(cc.v2(this.node.x / 3, this.node.y / 3));
        this.initMotionNode();
        this.toggleMotionNode(true);
        isPlayerStop = true;
      },
      tutorialThree: function tutorialThree() {
        this.initMotionNode();
        this.floorJump.active = true;
        isPlayerStop = true;
        this.tutorialText.string = "快速地摇动你的手机来跳跃到另一块木板上";
        this.tutorialText.string = "Quickly shake your phone to jump to the another wood";
        var textNode = this.tutorialText.node;
        textNode.setPosition(cc.v2(-this.node.x / 7, -this.node.y / 2));
      },
      tutorialFour: function tutorialFour() {
        tutorialIndex = 5;
        this.initMotionNode();
        this.floorJump.active = false;
        this.player.getChildByName("Status").active = true;
        this.tutorialText.node.setPosition(cc.v2(this.node.x / 3, this.node.y / 3));
        this.tutorialText.string = "接下来就是介绍角色的状态啦（点击屏幕继续）";
        this.tutorialText.string = "Then we will introduce the status of the role (click on the screen to continue)";
      },
      tutorialFive: function tutorialFive() {
        var playerScript = this.player.getComponent("player");
        playerScript.statusControl(1);
        this.tutorialText.string = "混乱状态：角色将往控制方向相反移动（点击屏幕继续）";
        this.tutorialText.string = "Chaos:The role will move in the opposite direction of control (click on the screen to continue)";
        tutorialIndex = 6;
      },
      tutorialSix: function tutorialSix() {
        var playerScript = this.player.getComponent("player");
        playerScript.statusControl(2);
        this.tutorialText.string = "狂暴状态：角色将移动得更快（点击屏幕继续）";
        this.tutorialText.string = "Rage:The role will move faster (click on the screen to continue)";
        tutorialIndex = 7;
      },
      tutorialSeven: function tutorialSeven() {
        this.initMotionNode();
        this.toggleMotionNode();
        var textNode = this.tutorialText.node;
        textNode.setPosition(cc.v2(8, 9));
        this.tutorialText.string = "哇！完成全部教程了！赶快开始游戏吧（点击屏幕开始游戏）";
        this.tutorialText.string = "Wow! Complete all tutorials! (click on the screen to start the game)";
        tutorialIndex = 8;
      },
      initMotionNode: function initMotionNode() {
        var playerComponent = this.player.getComponent("player"), currentFloor = this.floor;
        currentFloor = 4 != tutorialIndex ? this.floor : this.floorJump;
        playerComponent.xPosition = currentFloor.x;
        this.player.x = currentFloor.x;
        this.player.y = currentFloor.y;
        playerComponent.speed = 0;
        currentFloor.rotation = 0;
        currentFloor.getComponent("floor").baseRotateAngle = 0;
      },
      toggleMotionNode: function toggleMotionNode(flag) {
        if (flag) {
          this.player.opacity = 255;
          this.floor.opacity = 255;
        } else {
          this.player.opacity = 0;
          this.floor.opacity = 0;
        }
      },
      update: function update(dt) {
        if (2 === tutorialIndex) {
          var floorWidth = this.floor.width, playerWidth = this.player.width, floorX = this.floor.x, floorY = this.floor.y, playerX = this.player.x, playerY = this.player.y, distanceFromCenter = Math.sqrt((playerX - floorX) * (playerX - floorX) + (playerY - floorY) * (playerY - floorY));
          if (distanceFromCenter > (floorWidth + playerWidth) / 2) {
            this.tutorialText.string = "oh!用力过大了，请再试一次（点击屏幕重试）";
            this.tutorialText.string = "Oh!Shaking overly (click screen to try again)";
            tutorialTwoGoals.left = 0;
            tutorialTwoGoals.right = 0;
          }
        } else if (3 === tutorialIndex) {
          var floorJumpWidth = this.floorJump.width, floorJumpX = this.floorJump.x, floorJumpY = this.floorJump.y, playerX = this.player.x, playerY = this.player.y;
          floorJumpY > playerY && floorJumpY - 20 < playerY && (this.tutorialText.string = playerX < floorJumpX - floorJumpWidth / 2 ? "Oh!Shaking overly (click screen to try again)" : "Oh!too gently (click screen to try again)");
          if (this.player.getComponent("player").currentFloor === this.floorJump && playerX > floorJumpX - floorJumpWidth / 2 && playerY >= floorJumpY) {
            var textNode = this.tutorialText.node;
            this.tutorialText.string = "complete! Congratulations (click on the screen to continue)";
            tutorialIndex = 4;
            this.initMotionNode();
          }
        }
      },
      skipTutorial: function skipTutorial() {
        var userData = {
          highestScore: 0
        };
        cc.sys.localStorage.setItem("userData", JSON.stringify(userData));
        cc.audioEngine.stopAll();
        cc.director.loadScene("main");
      }
    });
    cc._RF.pop();
  }, {} ]
}, {}, [ "about", "credits", "creditsScene", "floor", "game", "gameOver", "global", "mainMenu", "mainMenuBtn", "player", "startGame", "tutorial" ]);